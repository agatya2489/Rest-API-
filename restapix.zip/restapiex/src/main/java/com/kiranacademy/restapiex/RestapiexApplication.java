package com.kiranacademy.restapiex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com") //Access to another packages data
@EntityScan("com")//Access to another packages data
public class RestapiexApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiexApplication.class, args);
	}

}
